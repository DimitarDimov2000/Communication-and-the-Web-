package de.tub.web;

import org.apache.hc.core5.net.URIBuilder;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class CatDogClient {

    private static final HttpClient client = HttpClient.newHttpClient();
    //I got tired, sorry if your dog breed isn't in here. Tbh I didn't know most of these...
    private static final List<String> validBreeds = Arrays.asList(
            "affenpinscher", "african", "airedale", "akita", "appenzeller", "australian",
            "basenji", "beagle", "bluetick", "borzoi", "bouvier", "boxer", "brabancon",
            "briard", "buhund", "bulldog", "bullterrier", "cairn", "cattledog", "chihuahua",
            "chow", "clumber", "cockapoo", "collie", "coonhound", "corgi", "cotondetulear",
            "dachshund", "dalmatian", "dane", "deerhound", "dhole", "dingo", "doberman",
            "elkhound", "entlebucher", "eskimo", "finnish", "frise", "germanshepherd",
            "greyhound", "groenendael", "hound", "husky", "keeshond", "kelpie", "komondor",
            "kuvasz", "labrador", "leonberg", "lhasa", "malamute", "malinois", "maltese",
            "mastiff", "mexicanhairless", "mix", "mountain", "newfoundland", "otterhound",
            "papillon", "pekinese", "pembroke", "pinscher", "pitbull", "pointer", "pomeranian",
            "poodle", "pug", "puggle", "pyrenees", "redbone", "retriever", "ridgeback",
            "rottweiler", "saluki", "samoyed", "schipperke", "schnauzer", "setter", "sheepdog",
            "shiba", "shihtzu", "spaniel", "spitz", "springer", "stbernard", "terrier",
            "vizsla", "weimaraner", "whippet", "wolfhound"
    );

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for the number of cat images
        System.out.print("Enter the number of cat images you want to see: ");
        int catImageCount = scanner.nextInt();

        // Prompt user for the number of dog images
        System.out.print("Enter the number of dog images you want to see: ");
        int dogImageCount = scanner.nextInt();

        // Fetch and display cat images
        System.out.println("Fetching cat images...");
        for (int i = 0; i < catImageCount; i++) {
            try {
                fetchCatImage();
            } catch (Exception e) {
                System.err.println("Failed to fetch cat image: " + e.getMessage());
            }
        }

        // Fetch and display dog images
        System.out.println("Fetching dog images...");
        String previousDogBreed = null;
        for (int i = 0; i < dogImageCount; i++) {
            try {
                previousDogBreed = fetchDogImage(previousDogBreed);
            } catch (Exception e) {
                System.err.println("Failed to fetch dog image: " + e.getMessage());
                previousDogBreed = null; // Reset breed if fetching fails
            }
        }

        scanner.close();
    }

    private static void fetchCatImage() throws Exception {
        URI uri = new URIBuilder()
                .setScheme("https")
                .setHost("api.thecatapi.com")
                .setPath("/v1/images/search")
                .build();

        HttpRequest request = HttpRequest.newBuilder(uri)
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        JSONArray jsonArray = new JSONArray(response.body());
        JSONObject jsonObject = jsonArray.getJSONObject(0);
        String imageUrl = jsonObject.getString("url");

        System.out.println("Cat Image: " + imageUrl);
    }

    private static String fetchDogImage(String breed) throws Exception {
        URIBuilder uriBuilder = new URIBuilder()
                .setScheme("https")
                .setHost("dog.ceo")
                .setPath("/api/breeds/image/random");

        if (breed != null && validBreeds.contains(breed)) {
            uriBuilder.setPath("/api/breed/" + breed + "/images/random");
        }

        URI uri = uriBuilder.build();

        HttpRequest request = HttpRequest.newBuilder(uri)
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        System.out.println("Response: " + response);

        System.out.println("Raw JSON: ");
        System.out.println(response.body());

        JSONObject jsonObject = new JSONObject(response.body());
        String imageUrl = jsonObject.getString("message");

        if (response.statusCode() == 404) {
            System.out.println("Dog Image: " + jsonObject.getString("message"));
            return null; // Return null if breed not found
        }

        System.out.println("Dog Image: " + imageUrl);

        // Extract the breed from the image URL
        String[] parts = imageUrl.split("/");
        String newBreed = parts[parts.length - 2];  // The breed is usually the second to last part of the URL

        // Validate the new breed
        if (!validBreeds.contains(newBreed)) {
            System.out.println("Invalid breed extracted: " + newBreed);
            return null;
        }

        System.out.println("Extracted breed: " + newBreed);
        return newBreed;
    }
}