package de.tub.grpc;

import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;

public class ServerMain {

    public static void main(String[] args) {
        Server server = ServerBuilder.forPort(9090)
                .addService(new ClientServerServiceImpl())
                .build();

        try {
            server.start();
            System.out.println("Server started on port 9090");

            // Add a shutdown hook to "gracefully" shut down the server
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                System.out.println("Shutting down gRPC server since JVM is shutting down");
                server.shutdown();
                System.out.println("Server shut down");
            }));

            // Wait for le termination of the server
            server.awaitTermination();
        } catch (IOException e) {
            System.err.println("Server failed to start: " + e.getMessage());
            e.printStackTrace();
        } catch (InterruptedException e) {
            System.err.println("Server interrupted: " + e.getMessage());
            e.printStackTrace();
        }
    }
}