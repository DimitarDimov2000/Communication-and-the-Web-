package de.tub.grpc;

import clientserver.ClientServer;
import clientserver.ClientServerServiceGrpc;
import de.tub.Assignment2Grpc;
import de.tub.Assignment2OuterClass;
import de.tub.Assignment2OuterClass.ZombieApocalypseAbility;
import de.tub.grpc.auth.AuthEncoder;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

import java.util.ArrayList;
import java.util.List;

public class ClientServerServiceImpl extends ClientServerServiceGrpc.ClientServerServiceImplBase {

    private static final String API_SERVER_TARGET = "34.32.36.165:8080";
    private static final String ISIS_EMAIL = "dimov@campus.tu-berlin.de";
    private static final String ISIS_MATRIKEL_NR = "481052";
    private static final String AUTH_STRING = AuthEncoder.generateAuthString(ISIS_EMAIL, ISIS_MATRIKEL_NR);

    @Override
    public void getSurvivalProbability(ClientServer.SurvivalRequest request, StreamObserver<ClientServer.SurvivalResponse> responseObserver) {
        ManagedChannel apiChannel = ManagedChannelBuilder.forTarget(API_SERVER_TARGET)
                .usePlaintext()
                .build();
        Assignment2Grpc.Assignment2BlockingStub apiStub = Assignment2Grpc.newBlockingStub(apiChannel);

        try {
            // Convert abilities from String to ZombieApocalypseAbility enum
            List<ZombieApocalypseAbility> abilities = new ArrayList<>();
            for (String ability : request.getAbilitiesList()) {
                try {
                    abilities.add(ZombieApocalypseAbility.valueOf(ability));
                } catch (IllegalArgumentException e) {
                    System.err.println("Invalid ability: " + ability);
                    responseObserver.onError(new IllegalArgumentException("Invalid ability: " + ability));
                    return;
                }
            }

            // Create and send a request to the API-SERVER
            Assignment2OuterClass.ZombieApocalypseRequest apiRequest = Assignment2OuterClass.ZombieApocalypseRequest.newBuilder()
                    .setAuth(AUTH_STRING)
                    .setName(request.getName())
                    .addAllAbilities(abilities)
                    .setStrength(request.getStrength())
                    .build();

            System.out.println("Sending request to API-SERVER: " + apiRequest);
            Assignment2OuterClass.ZombieApocalypseResponse apiResponse = apiStub.zombieApocalypse(apiRequest);
            System.out.println("Received response from API-SERVER: " + apiResponse);

            // Process the API-SERVER response and tell the client how grim it's looking
            String evaluation = apiResponse.getEvaluation();
            if (apiResponse.getProbabilityToSurviveOneYear() > 80) {
                evaluation = "Excellent survival chances!";
            } else if (apiResponse.getProbabilityToSurviveOneYear() < 50) {
                evaluation = "Your survival chances are low, consider improving your abilities.";
            }

            ClientServer.SurvivalResponse response = ClientServer.SurvivalResponse.newBuilder()
                    .setProbabilityToSurviveOneYear(apiResponse.getProbabilityToSurviveOneYear())
                    .setProbabilityToSurviveTwoYears(apiResponse.getProbabilityToSurviveTwoYears())
                    .setEvaluation(evaluation)
                    .build();

            responseObserver.onNext(response);
            responseObserver.onCompleted();
        } catch (Exception e) {
            System.err.println("Error occurred while processing request: " + e.getMessage());
            e.printStackTrace();
            responseObserver.onError(e);
        } finally {
            apiChannel.shutdown();
        }
    }
}