package de.tub.grpc;

import clientserver.ClientServer;
import clientserver.ClientServerServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class ClientMain {

    public static void main(String[] args) {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9090)
                .usePlaintext()
                .build();

        ClientServerServiceGrpc.ClientServerServiceBlockingStub stub = ClientServerServiceGrpc.newBlockingStub(channel);

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        System.out.print("Enter your abilities (comma separated): ");
        String[] abilitiesArray = scanner.nextLine().split(",");
        List<String> abilities = Arrays.asList(abilitiesArray);

        System.out.print("Enter your strength (1-10): ");
        int strength = scanner.nextInt();

        ClientServer.SurvivalRequest request = ClientServer.SurvivalRequest.newBuilder()
                .setName(name)
                .addAllAbilities(abilities)
                .setStrength(strength)
                .build();

        ClientServer.SurvivalResponse response = stub.getSurvivalProbability(request);

        System.out.println("Probability to survive one year: " + response.getProbabilityToSurviveOneYear());
        System.out.println("Probability to survive two years: " + response.getProbabilityToSurviveTwoYears());
        System.out.println("Evaluation: " + response.getEvaluation());

        channel.shutdown();
    }
}