package de.tub.grpc;

import de.tub.Assignment2Grpc;
import de.tub.Assignment2OuterClass;
import de.tub.grpc.auth.AuthEncoder;
import io.grpc.Grpc;
import io.grpc.InsecureChannelCredentials;
import io.grpc.ManagedChannel;
import io.grpc.StatusRuntimeException;

public class SimpleClient {
    static final String target = "34.32.36.165:8080";
    static final String isisEmail = "dimov@campus.tu-berlin.de";
    static final String isisMatrikelNr = "481052";
    static final String authString = AuthEncoder.generateAuthString(isisEmail, isisMatrikelNr);


    public static void main(String[] args) {
        // This is a very simple client to demonstrate how to send a request to the server
        // Please replace the MatrikelNr and E-Mail fields with your MatrikelNr and E-Mail first, and then check whether the Call works (i.e., does not return an error)
        ManagedChannel channel = Grpc.newChannelBuilder(target, InsecureChannelCredentials.create()).build();
        Assignment2Grpc.Assignment2BlockingStub stub = Assignment2Grpc.newBlockingStub(channel);

        try {

            System.out.println(stub.dummy(Assignment2OuterClass.DummyRequest.newBuilder().setAuth(authString).setInput(1337).build()));
        } catch (StatusRuntimeException e) {
            System.err.println("RPC failed: " + e.getStatus());
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            channel.shutdown();
        }
    }
}
